﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ajax_Jason.Models;
using Ajax_Jason.Models.ViewModels;

namespace Ajax_Jason.Controllers
{
    public class Ajax_JasonController : Controller
    {
        // GET: Ajax_Jason
        public ActionResult AJ_Index()
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();

            return View(ViewModels);
        }
        #region 下單畫面
        public ActionResult Orderdetils_Index()
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.New_Order_model = Models.Set_New_Order();
            ViewModels.New_Order_model.OrderDetial_list = new List<OrderDetial_list>();
            for (int a = 0; a < 7; a++)
            {
                ViewModels.New_Order_model.OrderDetial_list.Add(new OrderDetial_list());
            }
            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Orderdetils_Index(List<OrderDetial_list> ajs)
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            List<OrderDetial_list> return_list = new List<OrderDetial_list>();
            ViewModels.Production_list = Models.Production_list(null, null);
            for (int a = 0; a < ajs.Count; a++)
            {
                return_list.Add(ajs[a]);
                if (ajs[a].product_id != null)
                {
                    return_list[a].Productionnumber = ViewModels.Production_list.Find(x => x.product_id == return_list[a].product_id).number;
                    return_list[a].price = ViewModels.Production_list.Find(x => x.product_id == return_list[a].product_id).price.ToString();
                }
            }
            return Json(return_list);
        }
        public ActionResult Orderdetils_check(AJ_ViewModels ajs)
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            try{
                ViewModels.New_Order_model = Models.Set_New_Order();
                ViewModels.Production_list = Models.Production_list(null, null);
                ViewModels.New_Order_model.OrderDetial_list = ajs.New_Order_model.OrderDetial_list;
                Models.EXCE_OrderDetail(ajs.New_Order_model);
                ViewModels.New_Order_model.name = ajs.New_Order_model.name;
                ViewModels.New_Order_model.factory_name = ajs.New_Order_model.factory_name;
            }
            catch (Exception ex)
            {
                return RedirectToAction("Orderdetils_Index");
            }
            return View(ViewModels);
        }
        #endregion
        #region 商品首頁
        public ActionResult Product_homepage_Index()
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.product_homepage_model = new product_homepage_model();

            ViewModels.Types_list = Models.Types_list();
            ViewModels.Products_list = Models.Products_list(null, null);

            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Product_homepage_Index(AJ_ViewModels ajs)
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.product_homepage_model = new product_homepage_model();

            ViewModels.Types_list = Models.Types_list();
            ViewModels.Products_list = Models.Products_list(ajs.product_homepage_model.type_id, ajs.product_homepage_model.product_name);

            return View(ViewModels);
        }
        [HttpPost]
        public JsonResult texst_value(AJ_ViewModels ajs)
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();

            string return_value = "";
            if (ajs.product_homepage_model.type_id != null) return_value = "成功";
            else return_value = "不成功";

            return Json(return_value);
        }
        #endregion
        #region 商品新增修改刪除
        //商品進出貨結果明細
        //商品新增修改刪除
        public ActionResult Production_Index()
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();

            ViewModels.production_model = Models.Set_Production_model();
            ViewModels.Production_list = Models.Production_list(null,null);

            //ViewModels.production_model.type_id = ViewModels.Production_list[0].type_id;
            for (int a = 0; a < 5; a++)
            {
                ViewModels.Production_list.Add(new Production());
            }
            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Production_Index(AJ_ViewModels aj_s)
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.production_model = Models.Set_Production_model();

            ViewModels.production_model.type_id = aj_s.production_model.type_id??null;
            ViewModels.production_model.product_name = aj_s.production_model.product_name ?? null;
            ViewModels.Production_list = Models.Production_list(aj_s.production_model.type_id, aj_s.production_model.product_name);

            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult IS_UP_Production(AJ_ViewModels aj_s)
        {
            AJ_ViewModels ViewModels = aj_s;
            AJ_Models Models = new AJ_Models();

            try
            {
                Models.Insert_update_Products(aj_s.Production_list);
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("Production_Index");
        }
        #endregion
        #region 商品進貨、報銷紀錄
        //商品進出貨明細
        public ActionResult ProductionDetail_Index()
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.production_model = Models.Set_Production_model();

            ViewModels.ProductionDetail_list = new List<ProductionDetail>();
            for(int a = 0; a < 10; a++)
            {
                ViewModels.ProductionDetail_list.Add(new ProductionDetail());
            }
            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult ProductionDetail_Index(AJ_ViewModels aj_s)
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.production_model = Models.Set_Production_model();

            try
            {
                Models.EXCE_ProductionDetail(aj_s.ProductionDetail_list);
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("Production_Index");
        }
        #endregion
        #region 顧客購物紀錄
        //後端查看下單後商品清單
        public ActionResult Placing_order_Index()
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.placing_order_model = new placing_order_model();

            ViewModels.OrderDetial_list = Models.OrderDetial_list(null,null);

            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Placing_order_Index(AJ_ViewModels ajs)
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.placing_order_model = new placing_order_model();

            ViewModels.OrderDetial_list = Models.OrderDetial_list(ajs.placing_order_model.order_id, ajs.placing_order_model.customer_name);
            ViewModels.placing_order_model.order_id = ajs.placing_order_model.order_id;
            ViewModels.placing_order_model.customer_name = ajs.placing_order_model.customer_name;
            return View(ViewModels);
        }
        public ActionResult text()
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.placing_order_model = new placing_order_model();

            ViewModels.text_Order_list = Models.text_Order_list(null, null);
            ViewModels.text_OrderDetial_list = Models.text_OrderDetial_list(null);

            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult text(AJ_ViewModels ajs)
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.placing_order_model = new placing_order_model();

            ViewModels.text_Order_list = Models.text_Order_list(ajs.placing_order_model.order_id, ajs.placing_order_model.customer_name);
            ViewModels.text_OrderDetial_list = Models.text_OrderDetial_list(ajs.placing_order_model.order_id);
            ViewModels.placing_order_model.order_id = ajs.placing_order_model.order_id;
            ViewModels.placing_order_model.customer_name = ajs.placing_order_model.customer_name;
            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Get_Orderdetail_list(string input_order_id)
        {
            AJ_ViewModels ViewModels = new AJ_ViewModels();
            AJ_Models Models = new AJ_Models();
            ViewModels.placing_order_model = new placing_order_model();

            ViewModels.text_OrderDetial_list = Models.text_OrderDetial_list(input_order_id);

            return Json(ViewModels.text_OrderDetial_list);
        }
        #endregion
    }
}