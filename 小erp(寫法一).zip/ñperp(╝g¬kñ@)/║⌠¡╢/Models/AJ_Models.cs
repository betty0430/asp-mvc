﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SQL_Server_ClassLibrary;
using System.Web.Mvc;

namespace Ajax_Jason.Models
{
    public class Types
    {
        public List<SelectListItem> type_list { get; set; }
        //public string type_id { get; set; }//類型編號
        //public string name { get; set; }//類型姓名
    }

    public class Production
    {
        public string type_id { get; set; } //編號名稱
        public string type_name { get; set; } //編號名稱
        public string product_id { get; set; } //編號
        public string name { get; set; }//商品姓名
        public int number { get; set; }//庫存數量
        public int price { get; set; }//售貨價格
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }

        //public string type_name { get; set; }//類型姓名(編號)
    }

    public class Factory
    {
        public string Factory_id { get; set; }//編號
        public string name { get; set; }//工廠名
        public int address { get; set; }//地址
        public int Telephone { get; set; }//電話
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }
    }

    public class Employee
    {
        public string employee_id { get; set; }//編號
        public string name { get; set; }//員工名
        public string Factory_Name { get; set; }//工廠名
        public int address { get; set; }//地址
        public int Telephone { get; set; }//電話
        public DateTime? Arrival_date { get; set; }//到職日
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }
    }

    public class Customer
    {
        public string Customer_id { get; set; }//編號
        public string name { get; set; }//顧客名
        public string email { get; set; }//信箱
        public int address { get; set; }//地址
        public int Telephone { get; set; }//電話
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }
    }

    public class Order
    {
        public string Order_id { get; set; }//編號
        public string factory_name { get; set; }//工廠編號
        public string customer_name { get; set; }//顧客編號
        public int customer_address { get; set; }//顧客地址
        public int customer_telephone { get; set; }//顧客電話
        public DateTime? arrival_date { get; set; }//到貨日
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }
    }

    public class OrderDetial
    {
        public string order_id { get; set; }//編號
        public string customer_name { get; set; } //顧客名稱
        public string product_name { get; set; } //產品名稱
        public int number { get; set; }//銷售數量
        public string price { get; set; } //產品售價
        public string total { get; set; } //產品售價
        public string total2 { get; set; } //產品售價
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }
    }
    public class text_Order
    {
        public string order_id { get; set; }
        public string name { get; set; }
        public string total { get; set; }
    }
    public class text_OrderDetial
    {
        public string product_name { get; set; }
        public string number { get; set; }
        public string price { get; set; }
        public string total { get; set; }
    }
    public class New_Order
    {
        public string name { get; set; }//顧客
        public string factory_name { get; set; }//工廠編號
        public DateTime? arrival_date { get; set; }//到貨日
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }

        public List<SelectListItem> select_factory { get; set; }
        public List<SelectListItem> select_customername { get; set; }
        public List<OrderDetial_list> OrderDetial_list { get; set; }
        public List<SelectListItem> select_product { get; set; }
    }
    public class OrderDetial_list
    {
        public string product_id { get; set; }//編號
        public int number { get; set; }//銷售數量
        public int Productionnumber { get; set; }//銷售數量
        public string price { get; set; } //產品售價
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }

    }
    public class ProductionDetail
    {
        public string productiondetail_id { get; set; }//自動增長的編號
        public string inout_id { get; set; }//進出貨
        //public string type_id { get; set; }//類型編號
        public string product_id { get; set; }//商品姓名
        public int number { get; set; }//庫存數量
        public int price { get; set; }//售貨價格
        public DateTime? dr_date { get; set; }//創建日期
        public DateTime? dt_date { get; set; }//更新日期
    }

    public class product_homepage_model
    {
        public string type_id { get; set; }//類型編號
        public string product_name { get; set; } //產品名稱
    }
    public class placing_order_model
    {
        public string order_id { get; set; }//編號
        public string customer_name { get; set; } //顧客名稱
        public string Hidden_order_id { get; set; }//編號
    }
    public class Production_model
    {
        public string type_id { get; set; }//類型編號
        public List<SelectListItem> select_inout_id { get; set; }
        public List<SelectListItem> select_type_id { get; set; }
        public List<SelectListItem> select_product { get; set; }
        public string product_name { get; set; } //產品名稱
    }
    public class ProductionDetail_model
    {
        public string up_num { get; set; }//上升
        public string down_num { get; set; } //下降
    }

    public class AJ_Models
    {
        private Class1 class1 = new Class1();
        public New_Order Set_New_Order()
        {
            New_Order return_value = new New_Order();
            return_value.select_factory = Factory_list();
            return_value.select_customername = CustomerName_list();
            return_value.select_product = Product_list();
            return return_value;
        }
        public Production_model Set_Production_model()
        {
            Production_model return_value = new Production_model();
            return_value.select_type_id = Types_list();
            return_value.select_inout_id = new List<SelectListItem>();
            return_value.select_inout_id.Add(new SelectListItem { Text = "入庫", Value = "0" });
            return_value.select_inout_id.Add(new SelectListItem { Text = "報銷", Value = "1" });
            return_value.select_product = ALLProduct_list();
            return return_value;
        }
        #region 基本清單
        // 通用的函數來取得 List<SelectListItem>
        private List<SelectListItem> GetSelectListItems(string sqlQuery)
        {
            List<SelectListItem> return_list = new List<SelectListItem>();

            // 查詢資料
            DataTable reader = class1.SQL_select_exce(sqlQuery);

            // 將資料讀取並轉換為 SelectListItem
            for (int a = 0; a < reader.Rows.Count; a++)
            {
                return_list.Add(new SelectListItem
                {
                    Text = reader.Rows[a]["Text"].ToString(),
                    Value = reader.Rows[a]["Value"].ToString()
                });
            }

            return return_list;
        }

        // 工廠下拉選單
        public List<SelectListItem> Factory_list()
        {
            string sql = "SELECT factory_id AS Value, name AS Text FROM API.dbo.Factory WITH(NOLOCK)";
            return GetSelectListItems(sql);
        }

        // 客戶名稱下拉選單
        public List<SelectListItem> CustomerName_list()
        {
            string sql = "SELECT customer_id AS Value, name AS Text FROM API.dbo.Customer WITH(NOLOCK)";
            return GetSelectListItems(sql);
        }

        // 類型下拉選單
        public List<SelectListItem> Types_list()
        {
            string sql = "SELECT type_id AS Value, name AS Text FROM API.dbo.Types WITH(NOLOCK)";
            return GetSelectListItems(sql);
        }

        // 產品下拉選單
        public List<SelectListItem> Product_list()
        {
            string sql = $@"SELECT product_id AS Value, name AS Text FROM API.dbo.Production WITH(NOLOCK)
                        where number> 0";
            return GetSelectListItems(sql);
        }

        // 產品下拉選單
        public List<SelectListItem> ALLProduct_list()
        {
            string sql = $@"SELECT product_id AS Value, name AS Text FROM API.dbo.Production WITH(NOLOCK)
                        ";
            return GetSelectListItems(sql);
        }
        #region old
        //public List<SelectListItem> Factory_list()
        //{
        //    List<SelectListItem> return_list = new List<SelectListItem>();
        //    string sql_list = string.Empty;
        //    sql_list += $"select factory_id as Value,name as Text from API.dbo.Factory  with(nolock)";

        //    // 將 SqlDataReader 轉換為 List<Product>
        //    DataTable reader = class1.SQL_select_exce(sql_list);

        //    // 讀取查詢結果
        //    for(int a=0;a< reader.Rows.Count; a++)
        //    {
        //        return_list.Add(new SelectListItem
        //        {
        //            Text = reader.Rows[a]["Text"].ToString(),//類型編號
        //            Value = reader.Rows[a]["Value"].ToString()
        //            //Selected = (a[1].ToString() == production_model.type_id)
        //        });
        //    }
        //    return return_list;
        //}
        //public List<SelectListItem> CustomerName_list()
        //{
        //    List<SelectListItem> return_list = new List<SelectListItem>();
        //    string sql_list = string.Empty;
        //    sql_list += $"select customer_id as Value,name as Text from API.dbo.Customer with(nolock)";

        //    // 將 SqlDataReader 轉換為 List<Product>
        //    DataTable reader = class1.SQL_select_exce(sql_list);

        //    // 讀取查詢結果
        //    for (int a = 0; a < reader.Rows.Count; a++)
        //    {
        //        return_list.Add(new SelectListItem
        //        {
        //            Text = reader.Rows[a]["Text"].ToString(),//類型編號
        //            Value = reader.Rows[a]["Value"].ToString()
        //            //Selected = (a[1].ToString() == production_model.type_id)
        //        });
        //    }
        //    return return_list;
        //}
        //public List<SelectListItem> Types_list()
        //{
        //    List<SelectListItem> return_list = new List<SelectListItem>();
        //    string sql_list = string.Empty;
        //    sql_list += $"select type_id as Value,name as Text from API.dbo.Types with(nolock)";

        //    // 將 SqlDataReader 轉換為 List<Product>
        //    DataTable reader = class1.SQL_select_exce(sql_list);

        //    // 讀取查詢結果
        //    for (int a = 0; a < reader.Rows.Count; a++)
        //    {
        //        return_list.Add(new SelectListItem
        //        {
        //            Text = reader.Rows[a]["Text"].ToString(),//類型編號
        //            Value = reader.Rows[a]["Value"].ToString()
        //            //Selected = (a[1].ToString() == production_model.type_id)
        //        });
        //    }
        //    return return_list;
        //}
        //public List<SelectListItem> Product_list()
        //{
        //    List<SelectListItem> return_list = new List<SelectListItem>();
        //    string sql_list = string.Empty;
        //    sql_list += $"select product_id as Value,name as Text from API.dbo.Production with(nolock)";

        //    // 將 SqlDataReader 轉換為 List<Product>
        //    DataTable reader = class1.SQL_select_exce(sql_list);

        //    // 讀取查詢結果
        //    // 讀取查詢結果
        //    for (int a = 0; a < reader.Rows.Count; a++)
        //    {
        //        return_list.Add(new SelectListItem
        //        {
        //            Text = reader.Rows[a]["Text"].ToString(),//類型編號
        //            Value = reader.Rows[a]["Value"].ToString()
        //            //Selected = (a[1].ToString() == production_model.type_id)
        //        });
        //    }
        //    return return_list;
        //}
        #endregion
        #endregion
        #region 搜尋清單
        public List<Production> Production_list(string type_id, string product_name)
        {
            List<Production> return_list = new List<Production>();

            string sql_list = string.Empty;

            if (!String.IsNullOrEmpty(type_id))//有資料
            {
                sql_list += $"and p.type_id='{type_id}'";
            }
            if (!String.IsNullOrEmpty(product_name))//有資料
            {
                sql_list += $"and p.name='{product_name}'";
            }
            sql_list = $@"select t.name as type_name,p.* from API.dbo.Production as p with (nolock)
                        left join API.dbo.Types as t with (nolock) on p.type_id = t.type_id 
                        where 1=1 {sql_list}
                        order by p.number";

            // 將 SqlDataReader 轉換為 List<Product>
            DataTable reader = class1.SQL_select_exce(sql_list);
            // 讀取查詢結果
            foreach (DataRow a in reader.Rows)
            {
                return_list.Add(new Production
                {
                    type_name = a.ItemArray[0].ToString(),
                    product_id = a.ItemArray[1].ToString(),
                    type_id = a.ItemArray[2].ToString().Trim(),
                    name = a.ItemArray[3].ToString(),
                    number = int.Parse(a.ItemArray[4].ToString()),
                    price = int.Parse(a.ItemArray[5].ToString())
                });
            }
            return return_list;
        }
        public List<Production> Products_list(string types_id, string sreach)
        {
            List<Production> return_list = new List<Production>();
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            if (!String.IsNullOrEmpty(types_id))//有資料
            {
                sql_list += $"and p.type_id='{types_id}'";
            }
            if (!String.IsNullOrEmpty(sreach))//有資料
            {
                sql_list += $"and p.name='{sreach}'";
            }
            sql_list = $@"select p.product_id,p.name,p.number,p.price from API.dbo.Production as p with (nolock)
                        where 1=1 and p.number>1 " +
                        sql_list;
            // 將 SqlDataReader 轉換為 List<Product>
            DataTable reader = class1.SQL_select_exce(sql_list);

            // 讀取查詢結果
            foreach (DataRow a in reader.Rows)
            {
                return_list.Add(new Production
                {
                    product_id = a.ItemArray[0].ToString(),
                    name = a.ItemArray[1].ToString(),
                    number = int.Parse(a.ItemArray[2].ToString()),
                    price = int.Parse(a.ItemArray[3].ToString())
                });
            }
            return return_list;
        }

        public List<Order> Order_list(string order_id)
        {
            List<Order> return_list = new List<Order>();
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            if (!String.IsNullOrEmpty(order_id))//有資料
            {
                sql_list = $"and o.order_id='{order_id}'";
            }
            sql_list = $@"select 
                        o.order_id,f.name as factory_name,c.name as customer_name,c.address as customer_address,
                        c.telephone as customer_telephone,o.arrival_date,o.dr_date,o.dt_date 
                        from API.dbo.Orders as o with(nolock)
                        left join API.dbo.Customer as c on o.name = c.customer_id
                        left join API.dbo.Factory as f on o.factory_name = f.factory_id
                        where 1=1" + sql_list;
            // 將 SqlDataReader 轉換為 List<Product>
            DataTable reader = class1.SQL_select_exce(sql_list);

            // 讀取查詢結果
            foreach (DataRow a in reader.Rows)
            {
                return_list.Add(new Order
                {
                    Order_id = a.ItemArray[0].ToString(),
                    factory_name = a.ItemArray[1].ToString(),
                    customer_name = a.ItemArray[2].ToString(),
                    customer_address = int.Parse(a.ItemArray[3].ToString()),
                    customer_telephone = int.Parse(a.ItemArray[4].ToString()),
                    arrival_date = DateTime.Parse(a.ItemArray[5].ToString()),
                    dr_date = DateTime.Parse(a.ItemArray[6].ToString()),
                    dt_date = DateTime.Parse(a.ItemArray[7].ToString())
                });
            }
            return return_list;
        }
        public List<OrderDetial> OrderDetial_list(string order_id, string customer_name)
        {
            List<OrderDetial> return_list = new List<OrderDetial>();
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            if (!String.IsNullOrEmpty(order_id))//有資料
            {
                sql_list = $"and od.order_id='{order_id}'";
            }
            if (!String.IsNullOrEmpty(customer_name))//有資料
            {
                sql_list += $"and c.name='{customer_name}'";
            }
            sql_list = $@"select od.order_id,c.name as customer_name,pd.name as product_name,od.number,pd.price,(od.number*pd.price) as total,odt.total2,o.dr_date,o.dt_date
                            from API.dbo.OrderDetail as od with(nolock)
                            left join API.dbo.Production as pd on pd.product_id = od.product_id
                            left join API.dbo.Orders as o on od.order_id = o.order_id
                            left join API.dbo.Customer as c on o.name = c.customer_id
                            left join
                            (select od.order_id, sum(od.number* pd.price) as total2 from API.dbo.OrderDetail as od with(nolock)
                            left join API.dbo.Production as pd on pd.product_id = od.product_id
                            group by od.order_id) as odt on od.order_id = odt.order_id
                            where 1 = 1" +
                        sql_list;
            // 將 SqlDataReader 轉換為 List<Product>
            DataTable reader = class1.SQL_select_exce(sql_list);

            // 讀取查詢結果
            foreach (DataRow a in reader.Rows)
            {
                return_list.Add(new OrderDetial
                {
                    order_id = a[0].ToString(),
                    customer_name = a[1].ToString(),
                    product_name = a[2].ToString(),
                    number = int.Parse(a[3].ToString()),
                    price = a[4].ToString(),
                    total = a[5].ToString(),
                    total2 = a[6].ToString(),
                });
            }
            return return_list;
        }

        public List<text_Order> text_Order_list(string order_id, string customer_name)
        {
            List<text_Order> return_list = new List<text_Order>();
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            if (!String.IsNullOrEmpty(order_id))//有資料
            {
                sql_list = $"and od.order_id='{order_id}'";
            }
            if (!String.IsNullOrEmpty(customer_name))//有資料
            {
                sql_list += $"and c.name='{customer_name}'";
            }
            sql_list = $@"select od.order_id,c.name, sum(od.number* pd.price) as total from API.dbo.OrderDetail as od with(nolock)
                        left join API.dbo.Production as pd on pd.product_id = od.product_id
                        left join API.dbo.Orders as o on od.order_id = o.order_id
                        left join API.dbo.Customer as c on o.name = c.customer_id
                        where 1=1" + sql_list +
                        "group by od.order_id ,c.name";
            // 將 SqlDataReader 轉換為 List<Product>
            DataTable reader = class1.SQL_select_exce(sql_list);

            // 讀取查詢結果
            foreach (DataRow a in reader.Rows)
            {
                return_list.Add(new text_Order
                {
                    order_id = a[0].ToString(),
                    name = a[1].ToString(),
                    total = a[2].ToString(),
                });
            }
            if (return_list.Count < 7)
            {
                for (int a = return_list.Count; a < 7; a++)
                {
                    return_list.Add(new text_Order());
                }
            }
            return return_list;
        }

        public List<text_OrderDetial> text_OrderDetial_list(string order_id)
        {
            List<text_OrderDetial> return_list = new List<text_OrderDetial>();
            string sql_list = string.Empty;
            if(order_id!=null)
            {
                //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
                if (!String.IsNullOrEmpty(order_id))//有資料
                {
                    sql_list = $"and od.order_id='{order_id}'";
                }
                sql_list = $@"select pd.name as product_name,od.number,pd.price,(od.number*pd.price) as total
                        from API.dbo.OrderDetail as od with(nolock)
                        left join API.dbo.Production as pd on pd.product_id = od.product_id
                        left join API.dbo.Orders as o on od.order_id = o.order_id
                        left join API.dbo.Customer as c on o.name = c.customer_id
                        where 1 = 1" +
                            sql_list;
                // 將 SqlDataReader 轉換為 List<Product>
                DataTable reader = class1.SQL_select_exce(sql_list);

                // 讀取查詢結果
                foreach (DataRow a in reader.Rows)
                {
                    return_list.Add(new text_OrderDetial
                    {
                        product_name = a[0].ToString(),
                        number = a[1].ToString(),
                        price = a[2].ToString(),
                        total = a[3].ToString(),
                    });
                }
            }
            if (return_list.Count < 7)
            {
                for(int a= return_list.Count; a < 7; a++)
                {
                    return_list.Add(new text_OrderDetial ());
                }
            }
            return return_list;
        }
        #endregion
        public List<ProductionDetail> EXCE_ProductionDetail(List<ProductionDetail> production)
        {
            List<ProductionDetail> return_list = new List<ProductionDetail>();
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            foreach (var alls in production)
            {
                if (alls.inout_id != null && alls.product_id != null && alls.number != 0 && alls.price != 0)
                {
                    sql_list = $@"exec [API].dbo.[production_insert_update]
                            @inout_id={alls.inout_id},
                            @product_id='{alls.product_id}',
                            @number={alls.number},
                            @price={alls.price}";

                    // 將 SqlDataReader 轉換為 List<Product>
                    DataTable reader = class1.SQL_select_exce(sql_list);
                }
            }
            return return_list;
        }
        public string EXCE_OrderDetail(New_Order OrderDetail)
        {
            string return_list = "";
            string sql_list = string.Empty;

            DataTable data = new DataTable();
            data.Columns.Add("product_id", typeof(string));
            data.Columns.Add("number", typeof(int));
            data.Columns.Add("price", typeof(int));
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            foreach (var alls in OrderDetail.OrderDetial_list)
            {
                if (alls.product_id != null)
                {
                    DataRow row = data.NewRow();
                    row["product_id"] = alls.product_id;
                    row["number"] = alls.number;
                    row["price"] = alls.price;
                    data.Rows.Add(row);
                }
            }
            if (OrderDetail.name != null && OrderDetail.factory_name != null)
            {
                try
                {
                    //EXEC InsertOrdersProcedure @Orders = @orderDetails, @name = 'John Doe', @price = 30.50;
                    sql_list = $@"exec [API].dbo.[InsertOrdersData]
                            @Orders=@OrdersDate,
                            @customer_name='{OrderDetail.name}',
                            @factory_name='{OrderDetail.factory_name}'";
                    //class1.SQL_exce_spectail(sql_list, data);
                    return_list= class1.SQL_exce_spectail(sql_list, data, OrderDetail.name,OrderDetail.factory_name);
                } catch (Exception ex)
                {
                    return_list = ex.Message;
                }
            }
            else
            {
                return_list = "值有錯誤";
            }
            return return_list;
        }

        public void Insert_update_Products(List<Production> input_list)
        {
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            sql_list = $@"
                        DECLARE @NewID INT;
                        SET @NewID = (SELECT ISNULL(MAX(CAST(SUBSTRING(product_id, 2, 4) AS INT)), 0) FROM API.dbo.Production);

                        IF EXISTS(select 1 from  API.dbo.Production where product_id=@product_id)
                        BEGIN
                            update  API.dbo.Production
                            set 
                                type_id=TRIM(@type_id),
                                name=TRIM(@name),
                                number=@number,
                                price=@price,
                                dt_date=SYSDATETIME()
                            where product_id=@product_id
                        END
                        else
                        BEGIN
                            insert into  API.dbo.Production
                            (
                                product_id,
                                type_id,
                                name,
                                number,
                                price,
                                dr_date
                            )
                            values
                            (
                                'P' + RIGHT('000' + CAST(@NewID + 1 AS VARCHAR(4)), 4), -- 生成唯一的 OrderDetail ID
                                TRIM(@type_id),
                                TRIM(@name),
                                @number,
                                @price,
                                SYSDATETIME()
                            )
                        END
                        ";

            DataTable data = new DataTable();

            data.Columns.Add("type_id", typeof(string));//編號名稱
            data.Columns.Add("type_name", typeof(string));//編號名稱
            data.Columns.Add("product_id", typeof(string));//編號
            data.Columns.Add("name", typeof(string));//商品姓名
            data.Columns.Add("number", typeof(int));//庫存數量
            data.Columns.Add("price", typeof(int));//售貨價格

            // 將 List 內的數據逐一加到 DataTable
            foreach (var product in input_list)
            {
                if (product.type_id != null && product.name != null && product.price != 0)
                {
                    DataRow row = data.NewRow();
                    row["type_id"] = product.type_id??"";
                    row["type_name"] = product.type_name ?? "";
                    row["product_id"] = product.product_id ?? "";
                    row["name"] = product.name ?? "";
                    row["number"] = product.number;
                    row["price"] = product.price;
                    data.Rows.Add(row);
                }
            }
            // 將 SqlDataReader 轉換為 List<Product>
            class1.SQL_insert_update(sql_list, data);
        }
        #region

        //public string SQL_exce_spectail(string sqlstring, DataTable data, string name, string factory_name)
        //{
        //    //string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
        //    string connectionString = "Data Source=DESKTOP-7Q8V1RG;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        //    SqlDataReader reader;
        //    string datas = "";
        //    try
        //    {
        //        using (SqlConnection conn = new SqlConnection(connectionString))
        //        {
        //            // 使用參數化查詢呼叫預存程序
        //            using (SqlCommand cmd = new SqlCommand("[API].dbo.[InsertOrdersData]", conn))
        //            {
        //                // 指定使用預存程序
        //                cmd.CommandType = CommandType.StoredProcedure;

        //                // 設定表值參數
        //                SqlParameter ordersParam = cmd.Parameters.AddWithValue("@Orders", data);
        //                ordersParam.SqlDbType = SqlDbType.Structured; // 指定為表值參數
        //                ordersParam.TypeName = "dbo.OrderDetailType2"; // 指定表值參數的型別

        //                // 設定其他參數
        //                cmd.Parameters.AddWithValue("@customer_name", name);  // 假設值 '1'
        //                cmd.Parameters.AddWithValue("@factory_name", factory_name);   // 假設值 '2'

        //                // 打開連接
        //                conn.Open();

        //                // 執行命令
        //                //cmd.ExecuteNonQuery();
        //                reader = cmd.ExecuteReader();
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        datas = ex.Message;
        //    }
        //    return datas;
        //}
        //public List<ProductionDetail> Insert_update_Productions(List<ProductionDetail> input_list)
        //{
        //    List<ProductionDetail> return_list = new List<ProductionDetail>();
        //    string sql_list = string.Empty;
        //    //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
        //    sql_list = $@"
        //                insert into  API.dbo.ProductionDetail
        //                    (
        //                        inout_id,
        //                        type_id,
        //product_id,
        //                        number,
        //                        price,
        //                        dr_date
        //                    )
        //                    values
        //                    (
        //                        TRIM(@inout_id),
        //                        TRIM(@type_id),
        //                        TRIM(@product_id),
        //                        @number,
        //                        @price,
        //                        SYSDATETIME()
        //                    )
        //                ";

        //    DataTable data = new DataTable();

        //    data.Columns.Add("inout_id", typeof(int));//編號
        //    data.Columns.Add("type_id", typeof(string));//編號名稱
        //    data.Columns.Add("product_id", typeof(string));//商品編號
        //    data.Columns.Add("number", typeof(int));//庫存數量
        //    data.Columns.Add("price", typeof(int));//售貨價格

        //    // 將 List 內的數據逐一加到 DataTable
        //    foreach (var product in input_list)
        //    {
        //        if (product.inout_id != 0 && product.product_id != null && product.number != 0)
        //        {
        //            DataRow row = data.NewRow();
        //            row["inout_id"] = product.inout_id;
        //            row["type_id"] = product.type_id;
        //            row["product_id"] = product.product_id;
        //            row["number"] = product.number;
        //            row["price"] = product.price;
        //            data.Rows.Add(row);
        //        }
        //    }
        //    // 將 SqlDataReader 轉換為 List<Product>
        //    class1.SQL_insert_update(sql_list, data);
        //    return return_list;
        //}
        #endregion
    }
}