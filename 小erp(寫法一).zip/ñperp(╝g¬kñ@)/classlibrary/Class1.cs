﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQL_Server_ClassLibrary
{
    public class Class1
    {
        public void SQL_insert_update(string sqlstring, DataTable data)
        {
            //string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            string connectionString = "Data Source=DESKTOP-7Q8V1RG;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            //DataTable datas;
            //SqlDataReader reader;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                for (int a = 0; a < data.Rows.Count; a++)
                {
                    using (SqlCommand cmd = new SqlCommand(sqlstring, conn))
                    {
                        try
                        {
                            cmd.Parameters.AddWithValue("@type_id", SqlDbType.VarChar).Value = data.Rows[a]["type_id"];
                            cmd.Parameters.AddWithValue("@product_id", SqlDbType.VarChar).Value = data.Rows[a]["product_id"];
                            cmd.Parameters.AddWithValue("@name", SqlDbType.VarChar).Value = data.Rows[a]["name"];
                            cmd.Parameters.AddWithValue("@number", SqlDbType.Int).Value = data.Rows[a]["number"];
                            cmd.Parameters.AddWithValue("@price", SqlDbType.Int).Value = data.Rows[a]["price"];
                            cmd.ExecuteNonQuery(); // 執行
                        }
                        catch (Exception ex)
                        {
                            cmd.Parameters.AddWithValue("@inout_id", SqlDbType.Int).Value = data.Rows[a]["inout_id"];
                            cmd.Parameters.AddWithValue("@type_id", SqlDbType.VarChar).Value = data.Rows[a]["type_id"];
                            cmd.Parameters.AddWithValue("@product_id", SqlDbType.VarChar).Value = data.Rows[a]["product_id"];
                            cmd.Parameters.AddWithValue("@number", SqlDbType.Int).Value = data.Rows[a]["number"];
                            cmd.Parameters.AddWithValue("@price", SqlDbType.Int).Value = data.Rows[a]["price"];
                            cmd.ExecuteNonQuery(); // 執行
                        }
                    }
                }
            }
        }
        public DataTable SQL_select_exce(string sqlstring)
        {
            //string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            string connectionString = "Data Source=DESKTOP-7Q8V1RG;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlDataReader reader;
            DataTable data = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sqlstring, conn))
                {
                    // 使用 SqlDataReader 來讀取回傳的資料
                    reader = cmd.ExecuteReader();
                    data.Load(reader);
                }
            }
            return data;
        }
        public string SQL_exce_spectail(string sqlstring, DataTable data, string name, string factory_name)
        {
            //string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            string connectionString = "Data Source=DESKTOP-7Q8V1RG;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlDataReader reader;
            string datas = "";
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    // 使用參數化查詢呼叫預存程序
                    using (SqlCommand cmd = new SqlCommand("[API].dbo.[InsertOrdersData]", conn))
                    {
                        // 指定使用預存程序
                        cmd.CommandType = CommandType.StoredProcedure;

                        // 設定表值參數
                        SqlParameter ordersParam = cmd.Parameters.AddWithValue("@Orders", data);
                        ordersParam.SqlDbType = SqlDbType.Structured; // 指定為表值參數
                        ordersParam.TypeName = "dbo.OrderDetailType2"; // 指定表值參數的型別

                        // 設定其他參數
                        cmd.Parameters.AddWithValue("@customer_name", name);  // 假設值 '1'
                        cmd.Parameters.AddWithValue("@factory_name", factory_name);   // 假設值 '2'

                        // 打開連接
                        conn.Open();

                        // 執行命令
                        //cmd.ExecuteNonQuery();
                        reader = cmd.ExecuteReader();
                    }
                }
            }
            catch (Exception ex)
            {
                datas = ex.Message;
            }
            return datas;
        }
        //public DataTable SQL_exce_spectail(string sqlstring, DataTable data)
        //{
        //    //string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
        //    string connectionString = "Data Source=DESKTOP-7Q8V1RG;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        //    SqlDataReader reader;
        //    DataTable datas = new DataTable();
        //    try
        //    {
        //        using (SqlConnection conn = new SqlConnection(connectionString))
        //        {
        //            conn.Open();
        //            using (SqlCommand cmd = new SqlCommand(sqlstring, conn))
        //            {
        //                //cmd.CommandType = CommandType.StoredProcedure;

        //                // 6. 添加表值參數 @Orders
        //                SqlParameter ordersParam = cmd.Parameters.AddWithValue("@OrdersDate", data);
        //                ordersParam.SqlDbType = SqlDbType.Structured;
        //                ordersParam.TypeName = "dbo.OrderDetailType2"; // 表值參數的類型
        //                                                               // 添加其他參數
        //                //reader = cmd.ExecuteReader();
        //                //data.Load(reader);
        //                cmd.ExecuteNonQuery();
        //            }
        //        }
        //    }
        //    catch(Exception ex)
        //    {

        //    }
        //    return datas;
        //}
        //public void SQL_insert_update(string sqlstring, DataTable data)
        //{
        //    //string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
        //    string connectionString = "Data Source=DESKTOP-7Q8V1RG;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        //    //DataTable datas;
        //    //SqlDataReader reader;
        //    using (SqlConnection conn = new SqlConnection(connectionString))
        //    {
        //        conn.Open();

        //        for (int a = 0; a < data.Rows.Count; a++)
        //        {
        //            using (SqlCommand cmd = new SqlCommand(sqlstring, conn))
        //            {
        //                cmd.Parameters.AddWithValue("@inout_id", SqlDbType.Int).Value = data.Rows[0]["inout_id"];
        //                cmd.Parameters.AddWithValue("@type_id", SqlDbType.VarChar).Value = data.Rows[0]["type_id"];
        //                cmd.Parameters.AddWithValue("@product_id", SqlDbType.VarChar).Value = data.Rows[0]["product_id"];
        //                cmd.Parameters.AddWithValue("@name", SqlDbType.VarChar).Value = data.Rows[0]["name"];
        //                cmd.Parameters.AddWithValue("@number", SqlDbType.Int).Value = data.Rows[0]["number"];
        //                cmd.Parameters.AddWithValue("@price", SqlDbType.Int).Value = data.Rows[0]["price"];
        //                cmd.ExecuteNonQuery(); // 執行
        //            }
        //        }
        //        //foreach (DataRow all in data.Rows)
        //        //{
        //        //    using (SqlCommand cmd = new SqlCommand(sqlstring, conn))
        //        //    {
        //        //        cmd.Parameters.AddWithValue("@type_id", SqlDbType.VarChar).Value = all.ItemArray[0];
        //        //        cmd.Parameters.AddWithValue("@product_id", SqlDbType.VarChar).Value = all.ItemArray[2];
        //        //        cmd.Parameters.AddWithValue("@name", SqlDbType.VarChar).Value = all.ItemArray[3];
        //        //        cmd.Parameters.AddWithValue("@number", SqlDbType.Int).Value = all.ItemArray[4];
        //        //        cmd.Parameters.AddWithValue("@price", SqlDbType.Int).Value = all.ItemArray[5];
        //        //        cmd.ExecuteNonQuery(); // 執行
        //        //    }
        //        //}
        //    }
        //}
        //public SqlDataReader SQL_select_exce(string sqlstring)
        //{
        //    string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
        //    DataTable data = new DataTable();
        //    SqlDataReader reader;
        //    using (SqlConnection conn = new SqlConnection(connectionString))
        //    {
        //        conn.Open();
        //        using (SqlCommand cmd = new SqlCommand(sqlstring, conn))
        //        {
        //            // 使用 SqlDataReader 來讀取回傳的資料
        //            using (reader = cmd.ExecuteReader())
        //            {
        //                // 逐行讀取資料
        //                while (reader.Read())
        //                {
        //                    data.Load(reader); // 直接將 SqlDataReader 的資料加載到 DataTable
        //                }
        //            }
        //        }
        //    }
        //    return reader;
        //}
    }
}
