﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace orders.Models
{
    public class MyModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
    }

    public class text_Models
    {
        public List<MyModel> get_data()
        {
            List<MyModel> return_list = new List<MyModel>();

            return_list = new List<MyModel>
            {
                new MyModel { Id = 1, Name = "商品A", Quantity = 10 },
                new MyModel { Id = 2, Name = "商品B", Quantity = 20 },
                new MyModel { Id = 3, Name = "商品C", Quantity = 30 }
            };

            return return_list;
        }
    }
}