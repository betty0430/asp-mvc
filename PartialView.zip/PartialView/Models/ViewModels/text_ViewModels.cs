﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace orders.Models.ViewModels
{
    
    public class text_ViewModels
    {
        public List<MyModel> product_list { get; set; }
    }
}