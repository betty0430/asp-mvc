﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using orders.Models.ViewModels;
using orders.Models;

namespace orders.Controllers
{
    public class textController : Controller
    {
        // GET: text
        public ActionResult Index()
        {
            return View();
        }

        // 返回部分 View 的內容
        public ActionResult GetTableContent()
        {
            // 模擬數據
            text_ViewModels ViewModels = new text_ViewModels();
            text_Models Models = new text_Models();

            ViewModels.product_list = Models.get_data();

            // 返回部分 View，帶上數據
            return PartialView("_TablePartial", ViewModels.product_list);
        }
    }
}