﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Linq;

namespace xml_import.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            string alls1 = "";
            string alls2 = "";
            XDocument xdoc = XDocument.Load("D:\\智邦學習\\xml_import\\xml_import\\Models\\example.xml");  // 讀取 XML 文件

            // 讀取 XML 中的所有元素
            foreach (XElement element in xdoc.Descendants())
            {
                alls1 += element.Name + " : " + element.Value + "/\r\t";
                switch (element.Name.ToString())
                {
                    case "bookstore":
                    case "book":
                        break;
                    default:
                        alls2 += element.Name + " : " + element.Value + "/\r\t";
                        break;
                }
            }

            ViewBag.Message1 = alls1;
            ViewBag.Message2 = alls2;
            return View();
        }

        public ActionResult Contact()
        {
            string alls = "";
            XmlDocument doc = new XmlDocument();
            doc.Load("D:\\智邦學習\\xml_import\\xml_import\\Models\\example.xml");  // 讀取 XML 文件

            // 讀取 XML 中的根節點
            XmlNode root = doc.DocumentElement;
            //bookstore/book
            // 遍歷所有子節點
            foreach (XmlNode node in root.ChildNodes)
            {
                alls += node.Name + " : " + node.InnerText + "\r\t";
            }

            ViewBag.Message = alls;
            return View();
        }

        public ActionResult xml()
        {
            int a = 1;
            string alls = string.Empty;
            using (XmlReader reader = XmlReader.Create("D:\\智邦學習\\xml_import\\xml_import\\Models\\example.xml"))
            {
                while (reader.Read())
                {
                    //檢查當前節點是否是空元素
                    if (reader.IsStartElement())
                    {
                        // 獲取節點名稱和內容
                        alls+=$"{a}. {reader.Name} : ";
                        reader.Read();  // 讀取下個節點
                        //檢查當前節點是否是一個 空元素reader.IsEmptyElement 
                        //判斷目前的值是否只有找到\n\t(回傳值為1)
                        if (reader.Value.IndexOf("\n\t") == 1 || reader.Value.IndexOf("\n\t") == 0)
                        {
                            alls += "這是一個空元素。/";
                        }
                        else
                        {
                            alls += $"{reader.Value}/\n\t";
                        }
                    }
                    a++;
                }
            }
            ViewBag.Message = alls;
            return View();
        }
    }
}