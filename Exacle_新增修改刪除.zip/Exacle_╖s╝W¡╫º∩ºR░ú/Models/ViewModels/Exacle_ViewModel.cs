﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using exacle_page.Models;

namespace exacle_page.Models.View_Models
{
    public class Exacle_ViewModel
    {
        public List<Students> Students_List { get; set; }
        //public StudentsEntities aa { get; set; }
    }
}