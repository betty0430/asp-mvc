﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using SQL_ClassLibrary;

namespace exacle_page.Models
{
    public class Students
    {
        public string st_Id { get; set; }
        public string Name { get; set; }
        public string Class { get; set; }
    }
    public class Exacle_Model
    {
        //public DataTable ExportData { get; set; }
        public List<Students> GetStudents()
        {
            List<Students> return_list = new List<Students>();
            string sqlstring = $@"select * from  [dbo].[Students] with (nolock)";//在这儿写sql语句
            return_list=sql_data(sqlstring,"select",null);
            return return_list;
        }

        public void Inster_Students(List<Students>input_list)
        {
            //https://medium.com/sally-thinking/%E7%A8%8B%E5%BC%8F%E5%AD%B8%E7%BF%92%E4%B9%8B%E8%B7%AF-day25-c-ado-net-%E8%87%AA%E8%A1%8C%E5%BB%BA%E7%AB%8B%E7%89%A9%E4%BB%B6-f2488aa995cf
            //https://hoohoo.top/blog/asp-dot-net-ms-sql-server-connect-tutorial/
            string sqlstring = "";
            sqlstring = $@"
                    IF EXISTS (SELECT 1 FROM Students WHERE st_Id = @st_Id)
                    BEGIN
                        UPDATE Students 
                        SET 
                        Name =@Name,
                        Class =@Class, 
                        up_date=getdate()
                        WHERE st_Id = @st_Id
                    END
                    ELSE
                    BEGIN
                        INSERT INTO Students (st_Id, Name, Class, cr_date)
                        VALUES (@st_Id,@Name,@Class,getdate());
                    END
                    ";//在这儿写sql语句
            sql_data(sqlstring, "insert/update", input_list);
        }

        public void Delete_Students()
        {
            string sqlstring = "";
            sqlstring = $@"
                    delete from Students
                    ";//在这儿写sql语句
            sql_data(sqlstring, "delete", null);
        }

        public List<Students> sql_data(string sqlstring,string value, List<Students> input_list)
        {
            List<Students> return_list = new List<Students>();
            //SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Students;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            SqlDataReader dr;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sqlstring, conn);
                switch (value)
                {
                    case "select":
                        dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            return_list.Add(new Students { st_Id = dr["st_Id"].ToString(), Name = dr["Name"].ToString(), Class = dr["Class"].ToString() });
                        }
                        break;
                    case "insert/update":
                        SqlParameter st_Id = cmd.Parameters.Add("@st_Id", SqlDbType.NVarChar);
                        SqlParameter Name = cmd.Parameters.Add("@Name", SqlDbType.NVarChar);
                        SqlParameter Class = cmd.Parameters.Add("@Class", SqlDbType.NVarChar);
                        for(int a = 0; a < input_list.Count; a++)
                        {
                            st_Id.Value = input_list[a].st_Id;
                            Name.Value = input_list[a].Name;
                            Class.Value = input_list[a].Class;
                            cmd.ExecuteNonQuery(); // 傳送指令
                        }
                        break;
                    case "delete":
                        cmd.ExecuteNonQuery(); // 傳送指令
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                //如果有错误，输出错误信息   // 捕获 SQL 异常并打印详细信息
                Console.WriteLine("SQL Error: " + ex.Message);
            }
            finally
            {
                conn.Close();   //关闭连接  
            }
            return return_list;
        }
    }
}