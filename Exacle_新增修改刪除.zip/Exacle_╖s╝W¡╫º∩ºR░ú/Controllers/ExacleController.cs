﻿using System;
using System.Collections.Generic;
//using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ClosedXML.Excel;
using exacle_page.Models;
using exacle_page.Models.View_Models;
using OfficeOpenXml;

namespace exacle_page.Controllers
{
    public class ExacleController : Controller
    {
        // GET: Exacle
        public ActionResult Exacle_Index()
        {
            Exacle_ViewModel exacle_ViewModel = new Exacle_ViewModel();
            Exacle_Model exacle_Model = new Exacle_Model();

            exacle_ViewModel.Students_List = exacle_Model.GetStudents();
            return View(exacle_ViewModel);
        }
        //檔案資料新增
        [HttpPost]
        public ActionResult File_Import(HttpPostedFileBase file)
        {
            Exacle_ViewModel exacle_ViewModel = new Exacle_ViewModel();
            Exacle_Model exacle_Model = new Exacle_Model();

            if (file != null && file.ContentLength > 0)
            {
                exacle_ViewModel.Students_List = new List<Students>();
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

                using (var package = new ExcelPackage(file.InputStream))
                {
                    var worksheet = package.Workbook.Worksheets[0];
                    var rowCount = worksheet.Dimension.Rows;

                    for (int row = 2; row <= rowCount; row++) // Skip header row
                    {
                        //string text = worksheet.Cells.Value[1,2];
                        var student = new Students
                        {
                            st_Id = worksheet.Cells[row, 1].Text,
                            Name = worksheet.Cells[row, 2].Text,
                            Class = worksheet.Cells[row, 3].Text
                        };
                        exacle_ViewModel.Students_List.Add(student);
                    }
                }
                exacle_Model.Inster_Students(exacle_ViewModel.Students_List);
                // Save the students list to your database or process it as needed
                //資料存處後，會將action轉跳到Exacle_Index
                return RedirectToAction("Exacle_Index");
            }

            return View();
        }
        //檔案資料刪除
        public ActionResult Exacle_Delete()
        {
            Exacle_ViewModel exacle_ViewModel = new Exacle_ViewModel();
            Exacle_Model exacle_Model = new Exacle_Model();

            exacle_Model.Delete_Students();
            //資料存處後，會將action轉跳到Exacle_Index
            return RedirectToAction("Exacle_Index");
        }
        //檔案匯出
        public ActionResult ExportToExcel()
        {
            //https://ithelp.ithome.com.tw/articles/10339744
            Exacle_Model exacle_Model = new Exacle_Model();
            var students = exacle_Model.GetStudents();
            #region 第一版
            /*
            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Students");

                worksheet.Cells[1, 1].Value = "ID";
                worksheet.Cells[1, 2].Value = "Name";
                worksheet.Cells[1, 3].Value = "Class";

                for (int i = 0; i < students.Count; i++)
                {
                    worksheet.Cells[i + 2, 1].Value = students[i].Id;
                    worksheet.Cells[i + 2, 2].Value = students[i].Name;
                    worksheet.Cells[i + 2, 3].Value = students[i].Class;
                }

                var stream = new MemoryStream(package.GetAsByteArray());
                var fileName = "Students.xlsx";
                var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                return File(stream, contentType, fileName);
            }*/
            #endregion
            #region 第二版
            try
            {
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("Students");

                    worksheet.Cell(1, 1).Value = "學號";
                    worksheet.Cell(1, 2).Value = "姓名";
                    worksheet.Cell(1, 3).Value = "班級";

                    for (int i = 0; i < students.Count; i++)
                    {
                        worksheet.Cell(i + 2, 1).Value = students[i].st_Id;
                        worksheet.Cell(i + 2, 2).Value = students[i].Name;
                        worksheet.Cell(i + 2, 3).Value = students[i].Class;
                    }

                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        stream.Position = 0;
                        var fileName = "Students.xlsx";
                        var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                        return File(stream.ToArray(), contentType, fileName);
                        //return File(stream, contentType, fileName);
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine(ex.Message);
                return new HttpStatusCodeResult(500, "Internal server error");
            }
            #endregion 
        }
    }
}