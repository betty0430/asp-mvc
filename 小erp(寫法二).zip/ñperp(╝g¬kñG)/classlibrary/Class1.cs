﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using AutoMapper;
//using AutoMapper.Data;


namespace OD_ClassLibrary
{
    public class Class1
    {
        #region 頁數
        public List<T> Numberofpages<T>(List<T> data,int number,int now_page) where T :new ()
        {
            List<T> return_list = new List<T>();
            return_list = data.Skip(number*(now_page-1)).Take(number+number*(now_page-1)).ToList();
            if (return_list.Count < number)
            {
                for(int a = return_list.Count; a < number; a++)
                {
                    return_list.Add(new T());
                }
            }
            return return_list;
        }
        #endregion
        #region database 轉成 list
        public List<T> database_to_list<T>(DataTable dt) where T : new()
        {
            List<T> return_list = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T obj = new T(); // 創建 T 的新實例
                foreach (DataColumn col in dt.Columns)
                {
                    var prop = obj.GetType().GetProperty(col.ColumnName); // 根據列名找對應的屬性
                    if (prop != null && row[col] != DBNull.Value) // 屬性存在且值非空
                        prop.SetValue(obj, row[col]); // 設置屬性值
                }
                return_list.Add(obj); // 添加到列表
            }
            return return_list;
        }
        public List<T> DataTableToListWithJson<T>(DataTable dt)
        {
            string json = JsonConvert.SerializeObject(dt); // 將 DataTable 轉為 JSON
            return JsonConvert.DeserializeObject<List<T>>(json); // 將 JSON 轉為 T 的列表
        }
        //public static List<T> ConvertDataTableToListWithAutomapper<T>(DataTable dt)
        //{
        //    var config = new MapperConfiguration(cfg =>
        //    {
        //        cfg.AddDataTableMapping(); // 自動映射 DataTable
        //    });
        //    var mapper = config.CreateMapper();

        //    return mapper.Map<List<T>>(dt); // 將 DataTable 映射到指定類型的列表
        //}
        #endregion
        #region sql 語法
        public DataTable SQL_select_exce(string sqlstring)
        {
            //string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            string connectionString = "Data Source=DESKTOP-7Q8V1RG;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlDataReader reader;
            DataTable data = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sqlstring, conn))
                {
                    // 使用 SqlDataReader 來讀取回傳的資料
                    reader = cmd.ExecuteReader();
                    data.Load(reader);
                }
            }
            return data;
        }
        public void SQL_insert_update(string sqlstring, DataTable data)
        {
            //string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            string connectionString = "Data Source=DESKTOP-7Q8V1RG;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            //DataTable datas;
            //SqlDataReader reader;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                for (int a = 0; a < data.Rows.Count; a++)
                {
                    using (SqlCommand cmd = new SqlCommand(sqlstring, conn))
                    {
                        try
                        {
                            cmd.Parameters.AddWithValue("@type_id", SqlDbType.VarChar).Value = data.Rows[a]["type_id"];
                            cmd.Parameters.AddWithValue("@product_id", SqlDbType.VarChar).Value = data.Rows[a]["product_id"];
                            cmd.Parameters.AddWithValue("@name", SqlDbType.VarChar).Value = data.Rows[a]["name"];
                            cmd.Parameters.AddWithValue("@number", SqlDbType.Int).Value = data.Rows[a]["number"];
                            cmd.Parameters.AddWithValue("@price", SqlDbType.Int).Value = data.Rows[a]["price"];
                            cmd.ExecuteNonQuery(); // 執行
                        }
                        catch (Exception ex)
                        {
                            cmd.Parameters.AddWithValue("@inout_id", SqlDbType.Int).Value = data.Rows[a]["inout_id"];
                            cmd.Parameters.AddWithValue("@type_id", SqlDbType.VarChar).Value = data.Rows[a]["type_id"];
                            cmd.Parameters.AddWithValue("@product_id", SqlDbType.VarChar).Value = data.Rows[a]["product_id"];
                            cmd.Parameters.AddWithValue("@number", SqlDbType.Int).Value = data.Rows[a]["number"];
                            cmd.Parameters.AddWithValue("@price", SqlDbType.Int).Value = data.Rows[a]["price"];
                            cmd.ExecuteNonQuery(); // 執行
                        }
                    }
                }
            }
        }
        public string SQL_exce_spectail(string sqlstring, DataTable data, string name, string factory_name)
        {
            //string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = API; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            string connectionString = "Data Source=DESKTOP-7Q8V1RG;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlDataReader reader;
            string datas = "";
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    // 使用參數化查詢呼叫預存程序
                    using (SqlCommand cmd = new SqlCommand("[orders].dbo.[InsertOrdersData]", conn))
                    {
                        // 指定使用預存程序
                        cmd.CommandType = CommandType.StoredProcedure;

                        // 設定表值參數
                        SqlParameter ordersParam = cmd.Parameters.AddWithValue("@Orders", data);
                        ordersParam.SqlDbType = SqlDbType.Structured; // 指定為表值參數
                        ordersParam.TypeName = "dbo.OrderDetailType2"; // 指定表值參數的型別

                        // 設定其他參數
                        cmd.Parameters.AddWithValue("@customer_name", name);  // 假設值 '1'
                        cmd.Parameters.AddWithValue("@factory_name", factory_name);   // 假設值 '2'

                        // 打開連接
                        conn.Open();

                        // 執行命令
                        //cmd.ExecuteNonQuery();
                        reader = cmd.ExecuteReader();
                    }
                }
            }
            catch (Exception ex)
            {
                datas = ex.Message;
            }
            return datas;
        }
        #endregion
    }
}
