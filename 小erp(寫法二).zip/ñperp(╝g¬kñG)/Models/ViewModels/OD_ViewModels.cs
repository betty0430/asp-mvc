﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using orders.Models;

namespace orders.Models.ViewModels
{
    public class OD_ViewModels
    {
        public product_homepage_model product_homepage_model { get; set; }
        public placing_order_model placing_order_model { get; set; }
        public Production_model products_model { get; set; }
        public Production_model production_model { get; set; }
        public New_Order New_Order_model { get; set; }
        public page Page { get; set; }

        public List<SelectListItem> Types_list { get; set; }
        public List<Production> Products_list { get; set; }
        public List<Production> Production_list { get; set; }
        public List<Factory> Factory_list { get; set; }
        public List<Employee> Employee_list { get; set; }
        public List<Customer> Customer_list { get; set; }
        public List<Order> Order_list { get; set; }
        //public List<text_Order> text_Order_list { get; set; }
        //public List<text_OrderDetial> text_OrderDetial_list { get; set; }
        public List<OrderDetial> OrderDetial_list { get; set; }
        public List<ProductionDetail> ProductionDetail_list { get; set; }
    }
}