﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using OD_ClassLibrary;
using System.Web.Mvc;
using Newtonsoft.Json;

namespace orders.Models
{
    public  class page
    {
        public int numbers { get; set; }//顯示數量
        public int now_page { get; set; }//目前頁數
        public int end_page { get; set; }//最後一頁數
    }
    public class Types
    {
        public List<SelectListItem> type_list { get; set; }
        //public string type_id { get; set; }//類型編號
        //public string name { get; set; }//類型姓名
    }

    public class Production
    {
        public string type_id { get; set; } //編號名稱
        public string type_name { get; set; } //編號名稱
        public string product_id { get; set; } //編號
        public string name { get; set; }//商品姓名
        public int number { get; set; }//庫存數量
        public int price { get; set; }//售貨價格
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }

        //public string type_name { get; set; }//類型姓名(編號)
    }

    public class Factory
    {
        public string Factory_id { get; set; }//編號
        public string name { get; set; }//工廠名
        public int address { get; set; }//地址
        public int Telephone { get; set; }//電話
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }
    }

    public class Employee
    {
        public string employee_id { get; set; }//編號
        public string name { get; set; }//員工名
        public string Factory_Name { get; set; }//工廠名
        public int address { get; set; }//地址
        public int Telephone { get; set; }//電話
        public DateTime? Arrival_date { get; set; }//到職日
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }
    }

    public class Customer
    {
        public string Customer_id { get; set; }//編號
        public string name { get; set; }//顧客名
        public string email { get; set; }//信箱
        public int address { get; set; }//地址
        public int Telephone { get; set; }//電話
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }
    }

    public class Order
    {
        public string order_id { get; set; }//編號
        public string name { get; set; }//客戶名稱
        public string arrival_date { get; set; }//到貨日
        public string total { get; set; }//總額

        //public DateTime? arrival_date { get; set; }//到貨日
    }

    public class OrderDetial
    {
        public string product_name { get; set; }//產品名稱
        public string number { get; set; }//銷售數量
        public string price { get; set; } //產品售價
        public string total { get; set; }//產品售價
    }

    public class New_Order
    {
        public string name { get; set; }//顧客
        public string factory_name { get; set; }//工廠編號
        public string Message { get; set; }//顧客
        public DateTime? arrival_date { get; set; }//到貨日
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }

        public List<SelectListItem> select_factory { get; set; }
        public List<SelectListItem> select_customername { get; set; }
        public List<OrderDetial_list> OrderDetial_list { get; set; }
        public List<SelectListItem> select_product { get; set; }
    }
    public class OrderDetial_list
    {
        public string product_id { get; set; }//編號
        public int number { get; set; }//銷售數量
        public int Productionnumber { get; set; }//銷售數量
        public string price { get; set; } //產品售價
        public DateTime? dr_date { get; set; }
        public DateTime? dt_date { get; set; }

    }
    public class ProductionDetail
    {
        public string productiondetail_id { get; set; }//自動增長的編號
        public string inout_id { get; set; }//進出貨
        //public string type_id { get; set; }//類型編號
        public string product_id { get; set; }//商品姓名
        public int number { get; set; }//庫存數量
        public int price { get; set; }//售貨價格
        public DateTime? dr_date { get; set; }//創建日期
        public DateTime? dt_date { get; set; }//更新日期
    }

    public class product_homepage_model
    {
        public string type_id { get; set; }//類型編號
        public string product_name { get; set; } //產品名稱
    }
    public class placing_order_model
    {
        public string order_id { get; set; }//編號
        public string customer_name { get; set; } //顧客名稱
        public string Hidden_order_id { get; set; }//編號
        public page Order_Page { get; set; }
        public page OrderDetail_Page { get; set; }
    }
    public class Production_model
    {
        public string type_id { get; set; }//類型編號
        public string product_name { get; set; } //產品名稱
        public string product_id { get; set; } //產品編號
        public List<SelectListItem> select_type_id { get; set; }
        public List<SelectListItem> select_inout_id { get; set; }
        public List<SelectListItem> select_product { get; set; }
        public page pd_page { get; set; }
    }
    public class ProductionDetail_model
    {
        public string up_num { get; set; }//上升
        public string down_num { get; set; } //下降
    }

    public class OD_Models
    {
        private Class1 class1 = new Class1();
        public New_Order Set_New_Order()
        {
            New_Order return_value = new New_Order();
            return_value.select_factory = Factory_list();
            return_value.select_customername = CustomerName_list();
            return_value.select_product = Product_list();
            return return_value;
        }
        public Production_model Set_Production_model()
        {
            Production_model return_value = new Production_model();
            return_value.select_type_id = Types_list();
            return_value.select_inout_id = new List<SelectListItem>();
            return_value.select_inout_id.Add(new SelectListItem { Text = "入庫", Value = "0" });
            return_value.select_inout_id.Add(new SelectListItem { Text = "報銷", Value = "1" });
            return_value.select_product = ALLProduct_list();
            return return_value;
        }
        #region 基本清單
        // 通用的函數來取得 List<SelectListItem>
        private List<SelectListItem> GetSelectListItems(string sqlQuery)
        {
            List<SelectListItem> return_list = new List<SelectListItem>();

            // 查詢資料
            return_list = class1.DataTableToListWithJson<SelectListItem>(class1.SQL_select_exce(sqlQuery));
            return return_list;
        }

        // 工廠下拉選單
        public List<SelectListItem> Factory_list()
        {
            string sql = "SELECT factory_id AS Value, name AS Text FROM orders.dbo.Factory WITH(NOLOCK)";
            return GetSelectListItems(sql);
        }

        // 客戶名稱下拉選單
        public List<SelectListItem> CustomerName_list()
        {
            string sql = "SELECT customer_id AS Value, name AS Text FROM orders.dbo.Customer WITH(NOLOCK)";
            return GetSelectListItems(sql);
        }

        // 類型下拉選單
        public List<SelectListItem> Types_list()
        {
            string sql = "SELECT type_id AS Value, name AS Text FROM orders.dbo.Types WITH(NOLOCK)";
            return GetSelectListItems(sql);
        }

        // 產品下拉選單
        public List<SelectListItem> Product_list()
        {
            string sql = $@"SELECT product_id AS Value, name AS Text FROM orders.dbo.Production WITH(NOLOCK)
                        where number> 0";
            return GetSelectListItems(sql);
        }

        // 產品下拉選單
        public List<SelectListItem> ALLProduct_list()
        {
            string sql = $@"SELECT product_id AS Value, name AS Text FROM orders.dbo.Production WITH(NOLOCK)";
            return GetSelectListItems(sql);
        }
        #endregion
        #region 搜尋清單
        public List<Production> Production_list(string type_id, string product_name,string product_id)
        {
            List<Production> return_list = new List<Production>();

            string sql_list = string.Empty;

            if (!String.IsNullOrEmpty(type_id))//有資料
            {
                sql_list += $"and p.type_id='{type_id}'";
            }
            if (!String.IsNullOrEmpty(product_id))//有資料
            {
                sql_list += $"and p.product_id='{product_id}'";
            }
            if (!String.IsNullOrEmpty(product_name))//有資料
            {
                sql_list += $"and p.name='{product_name}'";
            }
            sql_list = $@"select t.name as type_name,p.* from orders.dbo.Production as p with (nolock)
                        left join orders.dbo.Types as t with (nolock) on p.type_id = t.type_id 
                        where 1=1 {sql_list}
                        order by p.number";

            // 資料讀取
            return_list = class1.DataTableToListWithJson<Production>(class1.SQL_select_exce(sql_list));
            return return_list;
        }
        public List<Production> Products_list(string types_id, string sreach)
        {
            List<Production> return_list = new List<Production>();
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            if (!String.IsNullOrEmpty(types_id))//有資料
            {
                sql_list += $"and p.type_id='{types_id}'";
            }
            if (!String.IsNullOrEmpty(sreach))//有資料
            {
                sql_list += $"and p.name='{sreach}'";
            }
            sql_list = $@"select p.product_id,p.name,p.number,p.price from orders.dbo.Production as p with (nolock)
                        where 1=1 and p.number>1 " +
                        sql_list;
            //資料讀取
            return_list = class1.DataTableToListWithJson<Production>(class1.SQL_select_exce(sql_list));
            return return_list;
        }

        #region 搜尋清單
        public List<Order> Order_list(string order_id, string customer_name)
        {
            List<Order> return_list = new List<Order>();
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            if (!String.IsNullOrEmpty(order_id))//有資料
            {
                sql_list = $"and od.order_id='{order_id}'";
            }
            if (!String.IsNullOrEmpty(customer_name))//有資料
            {
                sql_list += $"and c.name='{customer_name}'";
            }
            sql_list = $@"select od.order_id,FORMAT(o.arrival_date, 'yyyy/MM/dd') as arrival_date,c.name, sum(od.number* pd.price) as total from orders.dbo.OrderDetail as od with(nolock)
                        left join orders.dbo.Production as pd on pd.product_id = od.product_id
                        left join orders.dbo.Orders as o on od.order_id = o.order_id
                        left join orders.dbo.Customer as c on o.name = c.customer_id
                        where 1=1  {sql_list}
                        group by od.order_id ,c.name,o.arrival_date 
                        order by od.order_id";
            return_list = class1.DataTableToListWithJson<Order>(class1.SQL_select_exce(sql_list));
            return return_list;
        }

        public List<OrderDetial> OrderDetial_list(string order_id)
        {
            List<OrderDetial> return_list = new List<OrderDetial>();
            string sql_list = string.Empty;
            if (order_id != null)
            {
                //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
                if (!String.IsNullOrEmpty(order_id))//有資料
                {
                    sql_list = $"and od.order_id='{order_id}'";
                }
                sql_list = $@"select pd.name as product_name,od.number,pd.price,(od.number*pd.price) as total
                        from orders.dbo.OrderDetail as od with(nolock)
                        left join orders.dbo.Production as pd on pd.product_id = od.product_id
                        left join orders.dbo.Orders as o on od.order_id = o.order_id
                        left join orders.dbo.Customer as c on o.name = c.customer_id
                        where 1 = 1" +
                            sql_list;
                // 資料讀取
                return_list = class1.DataTableToListWithJson<OrderDetial>(class1.SQL_select_exce(sql_list));
            }
            return return_list;
        }
        #endregion

        public List<ProductionDetail> ProductionDetail_history_list(string inout_id)
        {
            List<ProductionDetail> return_list = new List<ProductionDetail>();
            string sql = string.Empty;
            if (!string.IsNullOrEmpty(inout_id))
            {
                sql = $@"and inout_id ={inout_id}";
            }
            sql = $@"select 
            a.productiondetail_id,
            case a.inout_id
            when 0 then '入庫'
            when 1 then '報銷'
            end as inout_id,
            b.name as product_id,
            a.number,
            a.price
            from orders.dbo.ProductionDetail as a with(nolock)
            left join orders.dbo.Production as b on a.product_id=b.product_id

            where 1 = 1" +sql;
            return_list = class1.DataTableToListWithJson<ProductionDetail>(class1.SQL_select_exce(sql));
            return return_list;
        }
        #endregion
        #region EXCE
        public List<ProductionDetail> EXCE_ProductionDetail(List<ProductionDetail> production)
        {
            List<ProductionDetail> return_list = new List<ProductionDetail>();
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            foreach (var alls in production)
            {
                if (alls.inout_id != null && alls.product_id != null && alls.number != 0 && alls.price != 0)
                {
                    sql_list = $@"exec [orders].dbo.[production_insert_update]
                            @inout_id={alls.inout_id},
                            @product_id='{alls.product_id}',
                            @number={alls.number},
                            @price={alls.price}";

                    // 將 SqlDataReader 轉換為 List<Product>
                    DataTable reader = class1.SQL_select_exce(sql_list);
                }
            }
            return return_list;
        }
        public string EXCE_OrderDetail(New_Order OrderDetail)
        {
            string return_list = "";
            string sql_list = string.Empty;

            DataTable data = new DataTable();
            data.Columns.Add("product_id", typeof(string));
            data.Columns.Add("number", typeof(int));
            data.Columns.Add("price", typeof(int));
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            foreach (var alls in OrderDetail.OrderDetial_list)
            {
                if (alls.product_id != null)
                {
                    DataRow row = data.NewRow();
                    row["product_id"] = alls.product_id;
                    row["number"] = alls.number;
                    row["price"] = alls.price;
                    data.Rows.Add(row);
                }
            }
            if (OrderDetail.name != null && OrderDetail.factory_name != null)
            {
                try
                {
                    //EXEC InsertOrdersProcedure @Orders = @orderDetails, @name = 'John Doe', @price = 30.50;
                    sql_list = $@"exec [orders].dbo.[InsertOrdersData]
                            @Orders=@OrdersDate,
                            @customer_name='{OrderDetail.name}',
                            @factory_name='{OrderDetail.factory_name}'";
                    //class1.SQL_exce_spectail(sql_list, data);
                    return_list= class1.SQL_exce_spectail(sql_list, data, OrderDetail.name,OrderDetail.factory_name);
                } catch (Exception ex)
                {
                    return_list = ex.Message;
                }
            }
            else
            {
                return_list = "值有錯誤";
            }
            return return_list;
        }
        #endregion
        #region 新增以及修改
        #region 方法一
        public void Insert_update_Products2(List<Production> input_list)
        {
            string sql_list = string.Empty;

            try
            {
                foreach (var product in input_list)
                {
                    if (product.type_id != null && product.name != null && product.price != 0)
                    {
                        sql_list = $@"
                        DECLARE @NewID INT;
                        SET @NewID = (SELECT ISNULL(MAX(CAST(SUBSTRING(product_id, 2, 4) AS INT)), 0) FROM orders.dbo.Production);

                        IF EXISTS(select 1 from  orders.dbo.Production where product_id='{product.product_id ?? ""}')
                        BEGIN
                            update  orders.dbo.Production
                            set 
                                type_id=TRIM('{product.type_id ?? ""}'),
                                name=TRIM('{product.name ?? ""}'),
                                number={product.number},
                                price={product.price},
                                dt_date=SYSDATETIME()
                            where product_id='{product.product_id ?? ""}'
                        END
                        else
                        BEGIN
                            insert into  orders.dbo.Production
                            (
                                product_id,
                                type_id,
                                name,
                                number,
                                price,
                                dr_date
                            )
                            values
                            (
                                'P' + RIGHT('000' + CAST(@NewID + 1 AS VARCHAR(4)), 4), -- 生成唯一的 OrderDetail ID
                                TRIM('{product.type_id ?? ""}'),
                                TRIM('{product.name ?? ""}'),
                                {product.number},
                                {product.price},
                                SYSDATETIME()
                            )
                        END
                        ";
                        // 將 SqlDataReader 轉換為 List<Product>
                        class1.SQL_select_exce(sql_list);
                    }
                }
            }
            catch (Exception ex)
            {
                var a = ex.Message;
            }
        }
        #endregion
        #region 方法一
        public void Insert_update_Products1(List<Production> input_list)
        {
            string sql_list = string.Empty;
            //如果 true 參數為 value 或空字串 ("")，則為 null，否則為 false。
            sql_list = $@"
                        DECLARE @NewID INT;
                        SET @NewID = (SELECT ISNULL(MAX(CAST(SUBSTRING(product_id, 2, 4) AS INT)), 0) FROM orders.dbo.Production);

                        IF EXISTS(select 1 from  orders.dbo.Production where product_id=@product_id)
                        BEGIN
                            update  orders.dbo.Production
                            set 
                                type_id=TRIM(@type_id),
                                name=TRIM(@name),
                                number=@number,
                                price=@price,
                                dt_date=SYSDATETIME()
                            where product_id=@product_id
                        END
                        else
                        BEGIN
                            insert into  orders.dbo.Production
                            (
                                product_id,
                                type_id,
                                name,
                                number,
                                price,
                                dr_date
                            )
                            values
                            (
                                'P' + RIGHT('000' + CAST(@NewID + 1 AS VARCHAR(4)), 4), -- 生成唯一的 OrderDetail ID
                                TRIM(@type_id),
                                TRIM(@name),
                                @number,
                                @price,
                                SYSDATETIME()
                            )
                        END
                        ";

            DataTable data = new DataTable();

            data.Columns.Add("type_id", typeof(string));//編號名稱
            data.Columns.Add("type_name", typeof(string));//編號名稱
            data.Columns.Add("product_id", typeof(string));//編號
            data.Columns.Add("name", typeof(string));//商品姓名
            data.Columns.Add("number", typeof(int));//庫存數量
            data.Columns.Add("price", typeof(int));//售貨價格

            // 將 List 內的數據逐一加到 DataTable
            foreach (var product in input_list)
            {
                if (product.type_id != null && product.name != null && product.price != 0)
                {
                    DataRow row = data.NewRow();
                    row["type_id"] = product.type_id??"";
                    row["type_name"] = product.type_name ?? "";
                    row["product_id"] = product.product_id ?? "";
                    row["name"] = product.name ?? "";
                    row["number"] = product.number;
                    row["price"] = product.price;
                    data.Rows.Add(row);
                }
            }
            // 將 SqlDataReader 轉換為 List<Product>
            class1.SQL_insert_update(sql_list, data);
        }
        #endregion
        #endregion
    }
}