﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using orders.Models;
using orders.Models.ViewModels;
using OD_ClassLibrary;

namespace orders.Controllers
{
    public class ordersController : Controller
    {
        private Class1 class1 = new Class1();
        // GET: orders
        public ActionResult OD_Index()
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();

            return View(ViewModels);
        }
        #region 下單畫面
        public ActionResult Orderdetils_Index()
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.New_Order_model = Models.Set_New_Order();
            ViewModels.New_Order_model.OrderDetial_list = new List<OrderDetial_list>();
            for (int a = 0; a < 9; a++)
            {
                ViewModels.New_Order_model.OrderDetial_list.Add(new OrderDetial_list());
            }
            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Orderdetils_Index(List<OrderDetial_list> ajs)
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            List<OrderDetial_list> return_list = new List<OrderDetial_list>();
            ViewModels.Production_list = Models.Production_list(null, null,null);
            for (int a = 0; a < ajs.Count; a++)
            {
                return_list.Add(ajs[a]);
                if (ajs[a].product_id != null)
                {
                    return_list[a].Productionnumber = ViewModels.Production_list.Find(x => x.product_id == return_list[a].product_id).number;
                    return_list[a].price = ViewModels.Production_list.Find(x => x.product_id == return_list[a].product_id).price.ToString();
                }
            }
            return Json(return_list);
        }
        public ActionResult Orderdetils_check(OD_ViewModels ajs)
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            try{
                ViewModels.New_Order_model = Models.Set_New_Order();
                ViewModels.Production_list = Models.Production_list(null, null,null);
                ViewModels.New_Order_model.OrderDetial_list = ajs.New_Order_model.OrderDetial_list;
                ViewModels.New_Order_model.Message= Models.EXCE_OrderDetail(ajs.New_Order_model);
                ViewModels.New_Order_model.name = ajs.New_Order_model.name;
                ViewModels.New_Order_model.factory_name = ajs.New_Order_model.factory_name;
            }
            catch (Exception ex)
            {
                return RedirectToAction("Orderdetils_Index");
            }
            return View(ViewModels);
        }
        #endregion
        #region 商品首頁
        public ActionResult Product_homepage_Index()
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.product_homepage_model = new product_homepage_model();

            ViewModels.Types_list = Models.Types_list();
            ViewModels.Products_list = Models.Products_list(null, null);

            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Product_homepage_Index(OD_ViewModels ajs)
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.product_homepage_model = new product_homepage_model();

            ViewModels.Types_list = Models.Types_list();
            ViewModels.Products_list = Models.Products_list(ajs.product_homepage_model.type_id, ajs.product_homepage_model.product_name);

            return View(ViewModels);
        }
        [HttpPost]
        public JsonResult texst_value(OD_ViewModels ajs)
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();

            string return_value = "";
            if (ajs.product_homepage_model.type_id != null) return_value = "成功";
            else return_value = "不成功";

            return Json(return_value);
        }
        #endregion
        #region 商品新增修改刪除
        //商品進出貨結果明細
        //商品新增修改刪除
        public ActionResult Production_Index()
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();

            ViewModels.production_model = Models.Set_Production_model();
            ViewModels.Production_list = Models.Production_list(null,null,null);

            //ViewModels.production_model.type_id = ViewModels.Production_list[0].type_id;
            for (int a = 0; a < 5; a++)
            {
                ViewModels.Production_list.Add(new Production());
            }
            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Production_Index(OD_ViewModels aj_s)
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.production_model = Models.Set_Production_model();

            ViewModels.production_model.type_id = aj_s.production_model.type_id??null;
            ViewModels.production_model.product_id = aj_s.production_model.product_id ?? null;
            ViewModels.production_model.product_name = aj_s.production_model.product_name ?? null;
            ViewModels.Production_list = Models.Production_list(aj_s.production_model.type_id, aj_s.production_model.product_name, aj_s.production_model.product_id);
            for (int a = 0; a < 5; a++)
            {
                ViewModels.Production_list.Add(new Production());
            }
            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult IS_UP_Production(OD_ViewModels aj_s)
        {
            OD_ViewModels ViewModels = aj_s;
            OD_Models Models = new OD_Models();

            try
            {
                Models.Insert_update_Products2(aj_s.Production_list);
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("Production_Index");
        }
        #endregion
        #region 商品進貨、報銷紀錄
        //商品進出貨明細歷史紀錄
        public ActionResult ProductionDetail_history_Index()
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.production_model = Models.Set_Production_model();
            ViewModels.ProductionDetail_list = Models.ProductionDetail_history_list(string.Empty);
            #region 頁數
            ViewModels.production_model.pd_page = new page();
            ViewModels.production_model.pd_page.now_page = 1;
            ViewModels.production_model.pd_page.numbers = 5;

            decimal pt = decimal.Parse(ViewModels.ProductionDetail_list.Count.ToString()) / decimal.Parse(ViewModels.production_model.pd_page.numbers.ToString());
            ViewModels.production_model.pd_page.end_page = (int)Math.Ceiling(pt);
            #endregion
            ViewModels.ProductionDetail_list = class1.Numberofpages<ProductionDetail>(ViewModels.ProductionDetail_list, ViewModels.production_model.pd_page.numbers, ViewModels.production_model.pd_page.now_page);
            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult ProductionDetail_history_Index(OD_ViewModels ajs)
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.production_model = Models.Set_Production_model();
            ViewModels.ProductionDetail_list = Models.ProductionDetail_history_list(string.Empty);
            #region 頁數
            ViewModels.production_model.pd_page = ajs.production_model.pd_page;

            decimal pt = decimal.Parse(ViewModels.ProductionDetail_list.Count.ToString()) / decimal.Parse(ViewModels.production_model.pd_page.numbers.ToString());
            ViewModels.production_model.pd_page.end_page = (int)Math.Ceiling(pt);
            #endregion
            ViewModels.ProductionDetail_list = class1.Numberofpages<ProductionDetail>(ViewModels.ProductionDetail_list, ViewModels.production_model.pd_page.numbers, ViewModels.production_model.pd_page.now_page);
            return View(ViewModels);
        }
        //商品進出貨明細
        public ActionResult ProductionDetail_Index()
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.production_model = Models.Set_Production_model();

            ViewModels.ProductionDetail_list = new List<ProductionDetail>();
            for(int a = 0; a < 10; a++)
            {
                ViewModels.ProductionDetail_list.Add(new ProductionDetail());
            }
            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult ProductionDetail_Index(OD_ViewModels aj_s)
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.production_model = Models.Set_Production_model();

            try
            {
                Models.EXCE_ProductionDetail(aj_s.ProductionDetail_list);
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("Production_Index");
        }
        #endregion
        #region 顧客購物紀錄
        //後端查看下單後商品清單
        public ActionResult Placing_order_Index()
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.placing_order_model = new placing_order_model();
            #region 頁數
            ViewModels.placing_order_model.Order_Page = new page();
            ViewModels.placing_order_model.OrderDetail_Page = new page();

            ViewModels.placing_order_model.Order_Page.now_page = 1;
            ViewModels.placing_order_model.OrderDetail_Page.now_page = 1;

            ViewModels.placing_order_model.Order_Page.numbers = 7;
            ViewModels.placing_order_model.OrderDetail_Page.numbers = 7;
            #endregion
            ViewModels.Order_list = Models.Order_list(null, null);
            ViewModels.OrderDetial_list = Models.OrderDetial_list(null);
            #region end_page
            /* Order_Page*/
            decimal pt = Math.Ceiling(decimal.Parse(ViewModels.Order_list.Count.ToString()) / decimal.Parse(ViewModels.placing_order_model.Order_Page.numbers.ToString())); // 自動進位
            ViewModels.placing_order_model.Order_Page.end_page = int.Parse(pt.ToString()); // 自動進位

            /* OrderDetail_Page*/
            pt = Math.Ceiling(decimal.Parse(ViewModels.OrderDetial_list.Count.ToString()) / decimal.Parse(ViewModels.placing_order_model.OrderDetail_Page.numbers.ToString())); // 自動進位
            ViewModels.placing_order_model.OrderDetail_Page.end_page = int.Parse(pt.ToString()); // 自動進位
            #endregion
            ViewModels.Order_list = class1.Numberofpages<Order>(ViewModels.Order_list, ViewModels.placing_order_model.Order_Page.numbers, ViewModels.placing_order_model.Order_Page.now_page);
            ViewModels.OrderDetial_list = class1.Numberofpages<OrderDetial>(Models.OrderDetial_list(null), ViewModels.placing_order_model.OrderDetail_Page.numbers, ViewModels.placing_order_model.OrderDetail_Page.now_page);

            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Placing_order_Index(OD_ViewModels ajs)
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.placing_order_model = new placing_order_model();
            ViewModels.placing_order_model.order_id = ajs.placing_order_model.order_id;
            ViewModels.placing_order_model.customer_name = ajs.placing_order_model.customer_name;

            ViewModels.Order_list = Models.Order_list(ajs.placing_order_model.order_id, ajs.placing_order_model.customer_name);
            ViewModels.OrderDetial_list = Models.OrderDetial_list(ajs.placing_order_model.order_id);
            #region 頁數
            ViewModels.placing_order_model.Order_Page = ajs.placing_order_model.Order_Page;

            ViewModels.placing_order_model.OrderDetail_Page = new page();
            ViewModels.placing_order_model.OrderDetail_Page.now_page = 1;
            ViewModels.placing_order_model.OrderDetail_Page.numbers = 7;
            #endregion
            #region end_page
            /* Order_Page*/
            decimal pt = Math.Ceiling(decimal.Parse(ViewModels.Order_list.Count.ToString()) / decimal.Parse(ViewModels.placing_order_model.Order_Page.numbers.ToString())); // 自動進位
            if (ViewModels.placing_order_model.Order_Page.end_page != pt)
            {
                ViewModels.placing_order_model.Order_Page.end_page = int.Parse(pt.ToString()); // 自動進位
                ViewModels.placing_order_model.Order_Page.now_page = 1;
            }

            /* OrderDetail_Page*/
            pt = Math.Ceiling(decimal.Parse(ViewModels.OrderDetial_list.Count.ToString()) / decimal.Parse(ViewModels.placing_order_model.OrderDetail_Page.numbers.ToString())); // 自動進位
            ViewModels.placing_order_model.OrderDetail_Page.end_page = int.Parse(pt.ToString()); // 自動進位
            #endregion
            ViewModels.Order_list = class1.Numberofpages<Order>(ViewModels.Order_list, ViewModels.placing_order_model.Order_Page.numbers, ViewModels.placing_order_model.Order_Page.now_page);
            ViewModels.OrderDetial_list = class1.Numberofpages<OrderDetial>(Models.OrderDetial_list(null), ViewModels.placing_order_model.OrderDetail_Page.numbers, ViewModels.placing_order_model.OrderDetail_Page.now_page);

            return View(ViewModels);
        }
        [HttpPost]
        public ActionResult Get_Orderdetail_list(string input_order_id, string now_page, string end_page, string numbers)
        {
            OD_ViewModels ViewModels = new OD_ViewModels();
            OD_Models Models = new OD_Models();
            ViewModels.placing_order_model = new placing_order_model();
            ViewModels.placing_order_model.OrderDetail_Page = new page();

            ViewModels.placing_order_model.OrderDetail_Page.now_page = int.Parse(now_page??"0");
            ViewModels.placing_order_model.OrderDetail_Page.end_page = int.Parse(now_page ?? "0");
            ViewModels.placing_order_model.OrderDetail_Page.numbers = int.Parse(numbers ?? "0");
            ViewModels.OrderDetial_list = Models.OrderDetial_list(input_order_id);
            #region end_page
            var pt = Math.Ceiling(decimal.Parse(ViewModels.OrderDetial_list.Count.ToString()) / decimal.Parse(ViewModels.placing_order_model.OrderDetail_Page.numbers.ToString()));
            if (ViewModels.placing_order_model.OrderDetail_Page.end_page != pt)
            {
                ViewModels.placing_order_model.OrderDetail_Page.end_page = int.Parse(pt.ToString()); // 自動進位
                ViewModels.placing_order_model.OrderDetail_Page.now_page = 1;
            }
            #endregion
            ViewModels.OrderDetial_list = class1.Numberofpages<OrderDetial>(ViewModels.OrderDetial_list, ViewModels.placing_order_model.OrderDetail_Page.numbers, ViewModels.placing_order_model.OrderDetail_Page.now_page);
            return PartialView("Orderdetail_Partail", ViewModels);
            //return Json(ViewModels.OrderDetial_list);
        }
        #endregion
    }
}