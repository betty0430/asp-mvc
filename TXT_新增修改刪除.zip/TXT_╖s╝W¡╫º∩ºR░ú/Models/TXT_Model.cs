﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TXT_INPUT.Models
{
    public class txt
    {
        public string massage { get; set; }
    }
    public class Value
    {
        public string Name { get; set; }
    }
    public class TXT_Model
    {
        //public DataTable ExportData { get; set; }
        public List<Value> GetList()
        {
            List<Value> return_list = new List<Value>();
            string sqlstring = $@"select * from  [dbo].[TXT] with(nolock)";//在这儿写sql语句
            return_list=sql_data(sqlstring,"select",null);
            return return_list;
        }

        public void Inster_List(List<Value> input_list)
        {
            //https://medium.com/sally-thinking/%E7%A8%8B%E5%BC%8F%E5%AD%B8%E7%BF%92%E4%B9%8B%E8%B7%AF-day25-c-ado-net-%E8%87%AA%E8%A1%8C%E5%BB%BA%E7%AB%8B%E7%89%A9%E4%BB%B6-f2488aa995cf
            //https://hoohoo.top/blog/asp-dot-net-ms-sql-server-connect-tutorial/
            string sqlstring = "";
            sqlstring = $@"
                    IF EXISTS (select 1 from  [dbo].[TXT] with(nolock) WHERE Name = @Name)
                    BEGIN
                         UPDATE [dbo].[TXT] 
                        SET 
                        Name =@Name,
                        dt_date=getdate()
                        WHERE Name = @Name 
                    END
                    ELSE
                    BEGIN
                        INSERT INTO [dbo].[TXT] (Name, cr_date)
                        VALUES (@Name,getdate());
                    END
                    ";//在这儿写sql语句
            sql_data(sqlstring, "insert/update", input_list);
        }
        /*UPDATE [dbo].[TXT] 
                        SET 
                        Name =@Name,
                        dt_date=getdate()*/
        public void Delete_List()
        {
            string sqlstring = "";
            sqlstring = $@"
                    delete from [dbo].[TXT]
                    ";//在这儿写sql语句
            sql_data(sqlstring, "delete", null);
        }

        public List<Value> sql_data(string sqlstring,string value, List<Value> input_list)
        {
            List<Value> return_list = new List<Value>();
            //SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Students;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            SqlDataReader dr;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sqlstring, conn);
                switch (value)
                {
                    case "select":
                        dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            return_list.Add(new Value { Name = dr["Name"].ToString()});
                        }
                        break;
                    case "insert/update":
                        SqlParameter Name = cmd.Parameters.Add("@Name", SqlDbType.NVarChar);
                        for(int a = 0; a < input_list.Count; a++)
                        {
                            Name.Value = input_list[a].Name;
                            cmd.ExecuteNonQuery(); // 傳送指令
                        }
                        break;
                    case "delete":
                        cmd.ExecuteNonQuery(); // 傳送指令
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                //如果有错误，输出错误信息   // 捕获 SQL 异常并打印详细信息
                Console.WriteLine("SQL Error: " + ex.Message);
            }
            finally
            {
                conn.Close();   //关闭连接  
            }
            return return_list;
        }
    }
}