﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TXT_INPUT.Models;

namespace TXT_INPUT.Models.View_Models
{
    public class TXT_ViewModel
    {
        public txt txts { get; set; }
        public List<Value> List { get; set; }
        //public StudentsEntities aa { get; set; }
    }
}