﻿using System;
using System.Collections.Generic;
//using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using TXT_INPUT.Models;
using TXT_INPUT.Models.View_Models;

namespace TXT_INPUT.Controllers
{
    public class TXTController : Controller
    {
        // GET: Exacle
        public ActionResult TXT_Index(string inputvalue)
        {
            TXT_ViewModel TXT_ViewModel = new TXT_ViewModel();
            TXT_Model TXT_Model = new TXT_Model();
            TXT_ViewModel.txts = new txt();

            TXT_ViewModel.List = TXT_Model.GetList();
            TXT_ViewModel.txts.massage = inputvalue;
            return View(TXT_ViewModel);
        }
        //檔案資料新增
        [HttpPost]
        public ActionResult File_Import(HttpPostedFileBase file)
        {
            TXT_ViewModel TXT_ViewModel = new TXT_ViewModel();
            TXT_Model TXT_Model = new TXT_Model();
            //確認檔案內是否有值
            if (file != null && file.ContentLength > 0)
            {
                string txt_value = "";
                TXT_ViewModel.List = new List<Value>();
                //將檔案路徑和檔案名稱傳遞給 StreamReader 建構函數
                StreamReader sr = new StreamReader(file.InputStream);
                while ((txt_value = sr.ReadLine()) != null)
                {
                    if (txt_value.Length < 25)
                    {
                        TXT_ViewModel.List.Add(new Value { Name = txt_value });
                    }
                    else
                    {
                        return RedirectToAction("TXT_Index",new { Inputvalue= "失敗" });
                    }
                }
                //close the file
                sr.Close();
                TXT_Model.Inster_List(TXT_ViewModel.List);
                //資料存處後，會將action轉跳到Exacle_Index
                return RedirectToAction("TXT_Index", new { Inputvalue = "成功" });
            }

            return View();
        }
        //檔案資料新增
        public ActionResult TXT_Delete()
        {
            TXT_ViewModel TXT_ViewModel = new TXT_ViewModel();
            TXT_Model TXT_Model = new TXT_Model();

            TXT_Model.Delete_List();
            //資料存處後，會將action轉跳到Exacle_Index
            return RedirectToAction("TXT_Index");
        }
        //檔案匯出
        public ActionResult ExportToTXT()
        {
            TXT_ViewModel TXT_ViewModel = new TXT_ViewModel();
            TXT_Model TXT_Model = new TXT_Model();
            TXT_ViewModel.List = TXT_Model.GetList();
            #region 第二版
            try
            {
                #region 將資料會到已經存在的檔案上
                //StreamWriter sw = new StreamWriter("C:\\Test.txt");
                ////Write a line of text
                //sw.WriteLine("Hello World!!");
                ////Write a second line of text
                //sw.WriteLine("From the StreamWriter class");
                ////Close the file
                //sw.Close();
                #endregion

                List<string> alls = new List<string>();
                foreach(Value a in TXT_ViewModel.List)
                {
                    alls.Add(a.Name);
                }
                // 要写入 TXT 文件的数据
                string data = string.Join("\n", alls);

                using (var stream = new MemoryStream())
                {
                    // 将数据写入内存流
                    var byteArray = Encoding.UTF8.GetBytes(data);//使用 UTF-8 编码将字符串 data 转换为字节数组 

                    // 将字节数组写入内存流
                    /*byteArray：
                    这是一个包含要写入数据的字节数组。
                    数据通常是从字符串编码转换而来的，例如使用 Encoding.UTF8.GetBytes(data)。
                    
                    0：
                    这是字节数组中开始写入的位置索引。
                    在这种情况下，从数组的第一个字节开始写入。

                    byteArray.Length：
                    这是要写入的字节数。
                    在这里，写入整个字节数组的内容。*/
                    stream.Write(byteArray, 0, byteArray.Length);
                    stream.Position = 0;

                    // 设置文件名和 MIME 类型
                    var fileName = "output.txt";
                    var contentType = "text/plain";//定义文件的 MIME 类型。对于文本文件，MIME 类型是 "text/plain"

                    // 返回文件流
                    return File(stream.ToArray(), contentType, fileName);
                    //return File(stream, contentType, fileName);
                }
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine(ex.Message);
                return new HttpStatusCodeResult(500, "Internal server error");
            }
            #endregion 
        }
    }
}